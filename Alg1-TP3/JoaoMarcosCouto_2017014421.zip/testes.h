#ifndef TESTES_H
#define TESTES_H

#include "grafo.h"



void testeLeitura(graph *grafo, int numVertices) ; 

#endif 